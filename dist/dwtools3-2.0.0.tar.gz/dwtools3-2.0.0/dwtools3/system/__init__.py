"""
Cross-platform system tools such as file locking and temporary files.
"""
