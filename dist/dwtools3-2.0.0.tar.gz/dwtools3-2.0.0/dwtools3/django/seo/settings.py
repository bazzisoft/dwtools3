from dwtools3.django.helpers import SettingsProxy


class SEOSettings(SettingsProxy):
    pass
