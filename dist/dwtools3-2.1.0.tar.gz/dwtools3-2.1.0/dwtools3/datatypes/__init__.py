"""
Additional data types such as enumerations.
"""
from .enumx import EnumX
