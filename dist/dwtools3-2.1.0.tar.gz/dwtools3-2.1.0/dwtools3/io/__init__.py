"""
Functions and classes pertaining to IO.
"""
