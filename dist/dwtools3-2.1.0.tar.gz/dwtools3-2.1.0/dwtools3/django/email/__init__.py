"""
Package providing additional email services such as multipart
text/html emails, and rendering emails from templates.
"""
